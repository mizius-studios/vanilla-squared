package blob.vanillasquared.mixin.world.entity;

import blob.vanillasquared.util.api.modules.attributes.VSQAttributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityAttributesMixin {

    @Inject(method = "createLivingAttributes", at = @At("RETURN"))
    private static void vsq$addCustomAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
        cir.getReturnValue().add(VSQAttributes.MACE_PROTECTION);
        cir.getReturnValue().add(VSQAttributes.MAGIC_PROTECTION);
        cir.getReturnValue().add(VSQAttributes.DRIPSTONE_PROTECTION);
        cir.getReturnValue().add(VSQAttributes.SPEAR_PROTECTION);
    }
}
